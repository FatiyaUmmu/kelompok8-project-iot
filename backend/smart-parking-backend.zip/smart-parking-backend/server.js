// server.js - Smart Parking Backend dengan Database + Auth
require('dotenv').config();
const express = require('express');
const mqtt = require('mqtt');
const cors = require('cors');
const db = require('./database');

const app = express();
app.use(cors());
app.use(express.json());

//===================== API KEY AUTH MIDDLEWARE =====================
const apiKeyAuth = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  const validKey = process.env.API_KEY || 'rahasia123';
  
  if (!apiKey || apiKey !== validKey) {
    return res.status(401).json({ error: 'Unauthorized - Invalid API Key' });
  }
  next();
};

//===================== MQTT CONNECTION =====================
const mqttClient = mqtt.connect('mqtt://broker.hivemq.com:1883');

mqttClient.on('connect', () => {
  console.log('✅ MQTT connected to HiveMQ');
  
  // Subscribe ke semua topik
  mqttClient.subscribe('parking/lantai1/status');
  mqttClient.subscribe('parking/lantai2/status');
  mqttClient.subscribe('parking/lantai3/status');
  mqttClient.subscribe('parking/gate/detected');
  mqttClient.subscribe('parking/+/event');
  mqttClient.subscribe('parking/+/alert');
});

mqttClient.on('message', (topic, message) => {
  const payload = message.toString();
  console.log(`📨 ${topic}: ${payload}`);
  
  try {
    const data = JSON.parse(payload);
    
    // Simpan ke database berdasarkan topik
    if (topic.endsWith('/status')) {
      const lantai = parseInt(topic.split('/')[1].replace('lantai', ''));
      const stmt = db.prepare(`
        INSERT INTO parking_status 
        (lantai, slot_total, slot_terisi, slot_tersedia, slotA, slotB, slotC, gas_persen)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(
        lantai,
        data.slot_total || 3,
        data.slot_terisi || 0,
        data.slot_tersedia || 3,
        data.slotA || 0,
        data.slotB || 0,
        data.slotC || 0,
        data.gas_persen || 0
      );
    }
    else if (topic === 'parking/gate/detected') {
      const stmt = db.prepare(`
        INSERT INTO gate_events (lantai, jarak_cm, tersedia)
        VALUES (?, ?, ?)
      `);
      stmt.run(data.lantai, data.jarak_cm, data.tersedia);
    }
    else if (topic.endsWith('/event')) {
      const stmt = db.prepare(`
        INSERT INTO access_events (lantai, event, slot, uid, jam, biaya)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      stmt.run(data.lantai, data.event, data.slot, data.uid, data.jam, data.biaya);
    }
    else if (topic.endsWith('/alert')) {
      const stmt = db.prepare(`
        INSERT INTO alerts (lantai, gas_persen)
        VALUES (?, ?)
      `);
      stmt.run(data.lantai, data.gas_persen);
    }
  } catch (e) {
    console.error('Parse error:', e.message);
  }
});

//===================== REST API ENDPOINTS =====================

// GET status terbaru per lantai (perlu API Key)
app.get('/api/lantai/:id/status', apiKeyAuth, (req, res) => {
  const lantai = parseInt(req.params.id);
  const latest = db.prepare(`
    SELECT * FROM parking_status 
    WHERE lantai = ? 
    ORDER BY timestamp DESC LIMIT 1
  `).get(lantai);
  
  if (!latest) {
    return res.status(404).json({ error: 'No data found' });
  }
  res.json(latest);
});

// GET history per lantai (perlu API Key)
app.get('/api/lantai/:id/history', apiKeyAuth, (req, res) => {
  const lantai = parseInt(req.params.id);
  const history = db.prepare(`
    SELECT * FROM parking_status 
    WHERE lantai = ? 
    ORDER BY timestamp DESC LIMIT 100
  `).all(lantai);
  
  res.json(history);
});

// GET semua gate events
app.get('/api/gate/events', apiKeyAuth, (req, res) => {
  const events = db.prepare(`
    SELECT * FROM gate_events ORDER BY timestamp DESC LIMIT 50
  `).all();
  res.json(events);
});

// GET semua access events (masuk/keluar)
app.get('/api/access/events', apiKeyAuth, (req, res) => {
  const events = db.prepare(`
    SELECT * FROM access_events ORDER BY timestamp DESC LIMIT 50
  `).all();
  res.json(events);
});

// POST control - kirim perintah ke ESP32
app.post('/api/control', apiKeyAuth, (req, res) => {
  const { command } = req.body;
  
  if (!command || (command !== 'OPEN_GATE' && command !== 'RESET')) {
    return res.status(400).json({ error: 'Invalid command' });
  }
  
  mqttClient.publish('parking/control', command);
  console.log(`📤 Published: ${command}`);
  res.json({ status: 'sent', command });
});

// Health check (tanpa auth)
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    mqtt: mqttClient.connected ? 'connected' : 'disconnected',
    database: 'SQLite active'
  });
});

//===================== START SERVER =====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🔑 API Key: ${process.env.API_KEY || 'rahasia123'}`);
  console.log(`📊 Health: http://localhost:${PORT}/api/health`);
});