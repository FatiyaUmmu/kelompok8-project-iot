// database.js - SQLite untuk Smart Parking
const Database = require('better-sqlite3');
const db = new Database('parking.db');

// Buat tabel jika belum ada (PERHATIKAN TITIK KOMA di akhir setiap CREATE TABLE)
db.exec(`
  CREATE TABLE IF NOT EXISTS parking_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lantai INTEGER,
    slot_total INTEGER,
    slot_terisi INTEGER,
    slot_tersedia INTEGER,
    slotA INTEGER,
    slotB INTEGER,
    slotC INTEGER,
    gas_persen INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS gate_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lantai INTEGER,
    jarak_cm REAL,
    tersedia INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS access_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lantai INTEGER,
    event TEXT,
    slot TEXT,
    uid TEXT,
    jam INTEGER,
    biaya INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lantai INTEGER,
    gas_persen INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

console.log('✅ Database SQLite siap (parking.db)');

module.exports = db;